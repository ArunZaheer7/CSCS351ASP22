// this is is done to check when user enter HIS/HER gmail address. it will automate this task and test if email address entered perfectly or not
package co.selenium.assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class myfstselproj {

	WebDriver driver; 
	public void lauchBrowser()  {
		System.setProperty("webdriver.gecko.driver", "E:\\installer\\geckodriver-v0.31.0-win64\\geckodriver.exe");
		driver = new FirefoxDriver();
		
		driver.get("https://www.gmail.com/");
		driver.manage().window().maximize();
		driver.findElement(By.id("identifierId")).sendKeys("arunzaheer46@gmail.com");
		
		driver.findElement(By.className("Cwak9")).click();
		
		String at = driver.getTitle();
		String et ="gmail";
		if(at.equalsIgnoreCase(et)) {
			System.out.println("Test Successful");
		}
		else
		{
			System.out.println("Test Fail");
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		myfstselproj obj = new myfstselproj();
			obj.lauchBrowser();
	}

}
